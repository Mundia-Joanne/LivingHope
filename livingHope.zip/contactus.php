<!-- <?php 
	$name = $_POST['name'];
	$email = $_POST['email'];
	$subject = $_POST['subject'];
	$message = $_POST['message'];

	$to = "joannemundia@gmail.com";
	$subject = "Message incoming";
	$body = "This is an automated message.Please dont reply to this email .";

	mail($to, $subject, $body);

	echo "Message sent" ;
 ?> -->